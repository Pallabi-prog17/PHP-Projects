<!--footer-->
    <div class="footer">
       <p>&copy; 2021 Budget Beauty Parlour Admin Panel.</p>
    </div>
        <!--//footer-->