<div class=" sidebar" role="navigation">
	<div class="navbar-collapse">
		<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
			<ul class="nav" id="side-menu">
				<li>
					<a href="dashboard.php"><i class="fa fa-home nav_icon"></i>Dashboard</a>
				</li>
				
				<li>
					<a href="add-services.php"><i class="fa fa-cogs nav_icon"></i>Services<span class="fa arrow"></span> </a>
					<ul class="nav nav-second-level collapse">
						<li>
							<a href="add-services.php">Add Services</a>
						</li>
						<li>
							<a href="manage-services.php">Manage Services</a>
						</li>
					</ul>
				</li>
				</li>
				<li class="">
					<a href="category-list.php"><i class="fa fa-book nav_icon"></i>Category <span class="fa arrow"></span></a>
					<ul class="nav nav-second-level collapse">
						<li>
							<a href="category-list.php">Category List</a>
						</li>
						<li>
							<a href="add-category.php">Add Category</a>
						</li>
					</ul>
				</li>
				<li class="">
					<a href="about-us.php"><i class="fa fa-book nav_icon"></i>Web Info <span class="fa arrow"></span></a>
					<ul class="nav nav-second-level collapse">
						<li>
							<a href="about-us.php">About Us</a>
						</li>
						
					</ul>
				</li>
				<li class="">
					<a href="product-list.php"><i class="fa fa-book nav_icon"></i>Product <span class="fa arrow"></span></a>
					<ul class="nav nav-second-level collapse">
						<li>
							<a href="product-list.php">Product List</a>
						</li>
						<li>
							<a href="add-product.php">Add Product</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="new-appointment.php"><i class="fa fa-check-square-o nav_icon"></i>Appointment<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level collapse">
					
						<li>
							<a href="new-appointment.php">New Appointment</a>
						</li>
						<li>
							<a href="search-appointment.php">Search Appointment</a>
						</li>
						<li>
							<a href="accepted-appointment.php">Accepted Appointment</a>
						</li>
						<li>
							<a href="rejected-appointment.php">Rejected Appointment</a>
						</li>
					</ul>
				</li>
				<li class="">
					<a href="new-feedback.php"><i class="fa fa-check-square-o nav_icon"></i>Feedback<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level collapse">
						<li>
							<a href="new-feedback.php">New Feedback</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="customer-list.php" class="chart-nav"><i class="fa fa-users nav_icon"></i>Customer List</a>
				</li>
				<li>
					<a href="payments.php"><i class="fa fa-money nav_icon"></i>Payments</a>
				</li>
				<li>
					<a href="daily.php">
					<i class="fa fa-check-square-o nav_icon"></i>Report
					<span class="fa arrow"></span>
					</a>
					<ul class="nav nav-second-level collapse">
						<li>
							<a href="daily.php">Daily</a>
						</li>
						<li>
							<a href="weekly.php">Last Week</a>
						</li>
						<li>
							<a href="monthly.php">Last Month</a>
						</li>
					</ul>
				</li>
			</ul>
			<div class="clearfix"> </div>
		</nav>
	</div>
</div>